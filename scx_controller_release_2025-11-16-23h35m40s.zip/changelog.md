### scx_controller是使用Rust语言构建的自动化控制scx相关节点的工具
- 强制性开启官方不支持的APP
